window.addEventListener("load", fire);

function fire() {
	var particles = [],
		count = document.getElementsByClassName("part").length,
		radius = 10,
		smokeChance = 0.1,
		smokeRadius = 5,
		radDec = 1.2,
		fireW = 10,
		fireX = 40,
		coreRange = 15, // white part
		spreadX = 10, // controls particle zigzaging
		spreadY = 100, // max particle stopping point
		yMin = 15,
		delayInc = 20,
		randNum = function(min, max) {
			return Math.floor(Math.random() * (max - min)) + min;
		},
		color = [];
		// colors
		color["white"] = "rgb(255,255,255)";
		color["yellow"] = "rgb(255,220,0)";
		color["red"] = "rgb(255,80,0)";
		color["gray"] = "rgb(20,20,20)";
		color["black"] = "rgb(0,0,0)";

	for (var i = 0; i < count; ++i) {
		let isSmoke = Math.random() < smokeChance ? true : false,
			cx = fireX + (isSmoke ? randNum(-fireW*2,fireW*2) : randNum(-fireW,fireW)),
			transX = isSmoke ? 0 : randNum(-spreadX/2,spreadX/2),
			transY = isSmoke ? -spreadY : randNum(-yMin,-spreadY*0.75),
			startFill = cx < fireX + coreRange/2 && cx > fireX - coreRange/2 ? color["white"] : color["yellow"],
			dur = isSmoke ? 2400 : 1200,
			durSplit = dur/3;

		let fire1 = KUTE.fromTo(
			".part" + i,
			{
				attr: {
					// choose start color based whether in core of fire
					fill: isSmoke ? color["gray"] : startFill,
					r: isSmoke ? smokeRadius : radius,
					cx: cx
				},
				opacity: 0.6,
				svgTransform: {
					translate: [0,0]
				}
			},
			{
				attr: {
					fill: isSmoke ? color["gray"] : color["yellow"],
					r: isSmoke ? smokeRadius : radius-radDec,
					cx: cx
				},
				opacity: 0.4,
				svgTransform: {
					translate: [transX,transY*0.33]
				}
			},
			{
				duration: durSplit
			}
		);
		let fire2 = KUTE.fromTo(
			".part" + i,
			{
				attr: {
					fill: isSmoke ? color["gray"] : color["yellow"],
					r: isSmoke ? smokeRadius : radius-radDec,
					cx: cx
				},
				opacity: 0.4,
				svgTransform: {
					translate: [transX,transY*0.33]
				}
			},
			{
				attr: {
					fill: isSmoke ? color["gray"] : color["red"],
					r: isSmoke ? smokeRadius : radius-radDec*2,
					cx: cx
				},
				opacity: 0.2,
				svgTransform: {
					translate: [0,transY*0.67]
				}
			},
			{
				duration: durSplit
			}
		);
		let smoke = KUTE.fromTo(
			".part" + i,
			{
				attr: {
					fill: isSmoke ? color["gray"] : color["red"],
					r: isSmoke ? smokeRadius : radius-radDec*2,
					cx: cx
				},
				opacity: 0.2,
				svgTransform: {
					translate: [0,transY*0.67]
				}
			},
			{
				attr: {
					fill: color["black"],
					r: isSmoke ? smokeRadius : radius-radDec*4,
					cx: cx
				},
				opacity: 0,
				svgTransform: {
					translate: [transX,transY]
				}
			},
			{
				delay: durSplit,
				duration: durSplit
			}
		);
		let run = function() {
			particles[i] = fire1.chain(fire2, smoke).start();
			setTimeout(run,dur);
		}
		setTimeout(run,i*delayInc);
	}
}