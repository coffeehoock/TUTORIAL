A Pen created at CodePen.io. You can find this one at http://codepen.io/jkantner/pen/eWGBBa.

 An animated SVG fire powered by a high-performing JavaScript animation engine called KUTE.js