var svg = new Walkway({
  selector: 'svg',
  duration: '1000',
});
svg.draw();