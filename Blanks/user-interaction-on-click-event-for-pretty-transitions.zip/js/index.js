var posX;
var posY;
var clickNum = 0;
var textArray = ["Cool, huh?", "The center of the circle will be wherever you click!", "Lorem ipsum dolor sit amet", "consectetur adipiscing elit", "sed do eiusmod tempor incididunt", "The end"]
$(".content").mousemove(function(e) {
  posX = e.pageX - 50;
  posY = e.pageY - 50;
});

$(".content").click(function() {
  $(".content").append(
    "<div class='circle' style='left:" + posX + "px;top:" + posY + "px;'></div>"
  );

  setTimeout(function() {
    $(".text").html(textArray[clickNum]);
    clickNum += 1;
  }, 100);
  setTimeout(function() {
    $("div").remove(".circle");
  }, 1000);
  
 
});