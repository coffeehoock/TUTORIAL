A Pen created at CodePen.io. You can find this one at http://codepen.io/mattrothenberg/pen/VbQLJa.

 A rapid prototype of the Bootstrap v4 Dashboard Template: https://themes.getbootstrap.com/products/dashboard

Made with Vue, Tachyons, and Chart.js
